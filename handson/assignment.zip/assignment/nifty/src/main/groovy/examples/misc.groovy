package examples

class Triple{
	static Integer getTriple(Integer self){
		3 * self
	}
}
