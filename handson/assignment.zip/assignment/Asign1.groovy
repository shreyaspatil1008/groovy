Q: Given Nifty-17_Years_Data-V1.xlsx
Which is 17 years of Nifty data with Open, Close etc index 
Find out the year when stock market was crashed
(ie, year where change in maximum and minimum of Open index was maximum accross all years) 
Use functional techniques and below libs 
'builders.dsl:spreadsheet-builder-poi:1.0.5'
'builders.dsl:spreadsheet-builder-groovy:1.0.5'
The excel is present in data directory 



